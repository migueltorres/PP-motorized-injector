#pragma once
#include "NetworkUdp.h"
typedef NetworkUDP WiFiUDP;
